package com.cpt202.module3.util;

import com.cpt202.module3.exception.AppException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Component;

@Component
public class ResourcePermissionChecker {

    private static final String USER_ID_KEY = "userId";
    private static final String CONTRIBUTOR_FLAG_KEY = "isContributor";

    public Long requireContributorUserId(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session == null) {
            throw AppException.forbidden("Current user is not logged in.");
        }

        Object userIdValue = session.getAttribute(USER_ID_KEY);
        Object contributorFlagValue = session.getAttribute(CONTRIBUTOR_FLAG_KEY);

        if (userIdValue == null || contributorFlagValue == null) {
            throw AppException.forbidden("Current user session is incomplete.");
        }

        Long currentUserId = parseLongValue(userIdValue);
        if (!parseBooleanValue(contributorFlagValue)) {
            throw AppException.forbidden("Current user does not have contributor permission.");
        }

        return currentUserId;
    }

    private Long parseLongValue(Object value) {
        if (value instanceof Number number) {
            return number.longValue();
        }

        String text = value == null ? "" : value.toString().trim();
        if (text.isEmpty()) {
            throw AppException.forbidden("Current user session is incomplete.");
        }

        try {
            return Long.parseLong(text);
        } catch (NumberFormatException exception) {
            throw AppException.forbidden("Current user identity is invalid.");
        }
    }

    private boolean parseBooleanValue(Object value) {
        if (value instanceof Boolean booleanValue) {
            return booleanValue;
        }

        String text = value == null ? "" : value.toString().trim();
        return "true".equalsIgnoreCase(text)
                || "1".equals(text)
                || "yes".equalsIgnoreCase(text)
                || "y".equalsIgnoreCase(text);
    }
}
